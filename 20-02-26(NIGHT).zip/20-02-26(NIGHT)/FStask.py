# from FScontroller import Controller
import webview
import json
from FS.useful import get_indicator,formate_sttime,get_filemode,filemode_readable
from FS.icon import known_file_types
import pyperclip


class TaskPerformer:
    def __init__(self, fs):
        self.fs = fs


    def show_list(self):   
        return  self.fs.show_list()
        

    def open(self,name):
        self.fs.go_to(name)


    def backward(self):
        self.fs.go_back()
       

    def forward(self):
        self.fs.go_forward()
       

    def go_root(self):
        self.fs.go_to_root()
       

    def go_to_address(self,path):
        isDone,msg = self.fs.go_to_address(path)
        return {
            "isdone":isDone,
            "msg":msg
        }
       

    def rename(self,old,new):
        
        result = self.fs.rename(old,new)
       
        return result
        

    def cut(self,data):
        
        self.fs.unselect_all()
        for id in data:
            self.fs.select(id)
        self.fs.cut()
       

    def copy(self,data):
        
        self.fs.unselect_all()
        for id in data:
            self.fs.select(id)
        self.fs.copy()
       
        
    def paste(self):
        result = self.fs.paste()  
        return result

    def delete(self,data):
        
        self.fs.unselect_all()
        for filename in data:
            self.fs.delete(filename)
       

    def create_folder(self,name):
        
        name = self.fs.create_dir(name)
       
        return name

    def create_file(self,filename,content=""):
        
        name = self.fs.create_file(filename,content)
       
        return name

    def path_breaker(self):
        
        result = self.fs.path_break_cwd()
        return result
    
    def get_cwd(self):
        
        path = self.fs.get_cwd()
       
        return path

    def get_quick(self):
        
        result = [(key,path)for key,lst in self.fs.quick_access.data.items()for path in lst] 
       
        return result
        

    def pin_to_quick(self,path):
        
        lst = self.fs.path_breaker(path)
        if lst:
            self.fs.quick_access.add(lst[0],path)
       
    
    def unpin_to_quick(self,path):
        
        lst = self.fs.path_breaker(path)
        if lst:
            self.fs.quick_access.remove(lst[0],path)
       

    # def new_window(self):
        
    #     w1 = webview.create_window(
    #         title="FS Manager",
    #         url="frontend/main-window.html",
    #         width=1200,
    #         height=700,
    #         resizable=True,
    #         fullscreen=False,
    #         js_api=self
    #     )
       

    
    def open_search(self):
        
        w2 = webview.create_window(
            title="FS Manager",
            url="frontend/file-search.html",
            width=550,
            height=755,
            resizable=False,
            fullscreen=False,
            js_api=self
        )
       

    def ultra_search(self,search_for,search_where,prifix,extension,substring):
        
        result = self.fs.ultra_search(search_for,search_where,prifix,extension[1:] if extension.startswith('.') else extension ,substring)
       
        return result

    # hash
    def get_duplicates(self):
        
        data = self.fs.search_duplicate_files()
        results=[]
        for hash_,paths in data.items():
            results.append([[path.split('/')[-1],path] for path in paths])

       
        return results
    
    def find_dup(self,path):
        
        hash_= self.fs.search_hash_by_path(path)
        paths= self.fs.search_paths_by_hash(hash_)
        
       
        return {
            "paths":list(paths)
        }

    def copy_text(self,text):
        
        pyperclip.copy(text)
       

    def tag_search(self,tags):
        
        print(tags)
        paths = self.fs.mrvec.search_by_query(tags)
        results=[{"name":path.split('/')[-1],"path":path} for path in paths]
       
        return results

    def lock_files(self,paths):
        
        for path in paths:
            data = self.fs.get_node_by_path(path)
            node =  data.get("result",None)
            if node:
                self.fs.lock_file(node)               

    def unlock_files(self,paths):
        
        for path in paths:
            data = self.fs.get_node_by_path(path)
            node =  data.get("result",None)
            if node:
                self.fs.unlock_file(node)
       

     
