class Tree:
    def refresh_path(self, path):
        print("Refreshing:", path)
