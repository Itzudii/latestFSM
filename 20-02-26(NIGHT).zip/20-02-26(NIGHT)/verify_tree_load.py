
import os
import sys
import shutil
from FSstorage import Storage
from FStree import Tree

# Setup
if os.path.exists("save/root.pkl"):
    os.remove("save/root.pkl")
    print("Deleted save/root.pkl to force DB load.")

# Mock Storage to test without full DB if needed, or use real one
# For this verify, we'll try to use the real storage if it exists, otherwise we mock it.
# Actually, let's use the real storage class but maybe a test DB if we can, or just the real one if it's safe.
# The user said "polish", implying existing data might be there.
# Let's inspect what's in the DB first.

try:
    storage = Storage()
    print("Connected to DB.")
    
    # Check if DB has nodes
    rows = storage.get_tree_structure()
    print(f"DB has {len(rows)} nodes.")
    
    if len(rows) == 0:
        print("DB is empty. Adding a mock root for testing.")
        storage.add_node("root", "d:/", "d", None)
        storage.commit()
        rows = storage.get_tree_structure()
    
    # Test Tree Loading
    tree = Tree("save/root.pkl")
    tree.load_from_db(storage)
    
    if tree.root:
        print(f"Tree root loaded: {tree.root.name}")
        print(f"Root children count: {len(tree.root.childs) if tree.root.childs else 0}")
        if len(rows) > 1 and (tree.root.childs is None or len(tree.root.childs) == 0):
             print("WARNING: DB has nodes but root has no children. Check parent_id linking.")
        else:
             print("Verification SUCCESS: Tree loaded from DB.")
    else:
        print("Verification FAILED: Tree root is None.")

except Exception as e:
    print(f"Verification FAILED with error: {e}")
