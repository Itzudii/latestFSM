import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import os
import shutil
from pathlib import Path
from datetime import datetime
import platform

class FileManager:
    def __init__(self, root):
        self.root = root
        self.root.title("File Manager")
        self.root.geometry("1000x600")
        
        # Current directory
        self.current_path = str(Path.home())
        
        # Clipboard for cut/copy operations
        self.clipboard = None
        self.clipboard_operation = None  # 'copy' or 'cut'
        
        # Setup UI
        self.setup_ui()
        self.load_directory(self.current_path)
        
    def setup_ui(self):
        # Toolbar
        toolbar = tk.Frame(self.root, relief=tk.RAISED, borderwidth=2)
        toolbar.pack(side=tk.TOP, fill=tk.X)
        
        # Navigation buttons
        tk.Button(toolbar, text="← Back", command=self.go_back, width=8).pack(side=tk.LEFT, padx=2, pady=2)
        tk.Button(toolbar, text="↑ Up", command=self.go_up, width=8).pack(side=tk.LEFT, padx=2, pady=2)
        tk.Button(toolbar, text="⟳ Refresh", command=self.refresh, width=8).pack(side=tk.LEFT, padx=2, pady=2)
        tk.Button(toolbar, text="🏠 Home", command=self.go_home, width=8).pack(side=tk.LEFT, padx=2, pady=2)
        
        # Address bar
        tk.Label(toolbar, text="Path:").pack(side=tk.LEFT, padx=5)
        self.path_var = tk.StringVar(value=self.current_path)
        path_entry = tk.Entry(toolbar, textvariable=self.path_var, width=50)
        path_entry.pack(side=tk.LEFT, padx=2, pady=2, fill=tk.X, expand=True)
        path_entry.bind('<Return>', lambda e: self.load_directory(self.path_var.get()))
        
        tk.Button(toolbar, text="Go", command=lambda: self.load_directory(self.path_var.get()), width=5).pack(side=tk.LEFT, padx=2)
        
        # Search
        tk.Label(toolbar, text="Search:").pack(side=tk.LEFT, padx=5)
        self.search_var = tk.StringVar()
        self.search_var.trace('w', lambda *args: self.filter_files())
        tk.Entry(toolbar, textvariable=self.search_var, width=20).pack(side=tk.LEFT, padx=2)
        
        # Main container
        main_container = tk.Frame(self.root)
        main_container.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # File list with scrollbar
        list_frame = tk.Frame(main_container)
        list_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Treeview for file list
        columns = ('Size', 'Type', 'Modified')
        self.tree = ttk.Treeview(list_frame, columns=columns, show='tree headings')
        
        self.tree.heading('#0', text='Name')
        self.tree.heading('Size', text='Size')
        self.tree.heading('Type', text='Type')
        self.tree.heading('Modified', text='Modified')
        
        self.tree.column('#0', width=300)
        self.tree.column('Size', width=100)
        self.tree.column('Type', width=100)
        self.tree.column('Modified', width=150)
        
        # Scrollbars
        vsb = ttk.Scrollbar(list_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(list_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        
        self.tree.grid(row=0, column=0, sticky='nsew')
        vsb.grid(row=0, column=1, sticky='ns')
        hsb.grid(row=1, column=0, sticky='ew')
        
        list_frame.grid_rowconfigure(0, weight=1)
        list_frame.grid_columnconfigure(0, weight=1)
        
        # Bind events
        self.tree.bind('<Double-1>', self.on_double_click)
        self.tree.bind('<Button-3>', self.show_context_menu)
        
        # Right panel for file operations
        right_panel = tk.Frame(main_container, width=200, relief=tk.SUNKEN, borderwidth=1)
        right_panel.pack(side=tk.RIGHT, fill=tk.Y, padx=(5, 0))
        right_panel.pack_propagate(False)
        
        tk.Label(right_panel, text="File Operations", font=('Arial', 12, 'bold')).pack(pady=10)
        
        operations = [
            ("New Folder", self.create_folder),
            ("New File", self.create_file),
            ("Copy", self.copy_item),
            ("Cut", self.cut_item),
            ("Paste", self.paste_item),
            ("Rename", self.rename_item),
            ("Delete", self.delete_item),
            ("Properties", self.show_properties),
        ]
        
        for text, command in operations:
            tk.Button(right_panel, text=text, command=command, width=15).pack(pady=5)
        
        # Status bar
        self.status_bar = tk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # Context menu
        self.context_menu = tk.Menu(self.root, tearoff=0)
        self.context_menu.add_command(label="Open", command=self.open_item)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Copy", command=self.copy_item)
        self.context_menu.add_command(label="Cut", command=self.cut_item)
        self.context_menu.add_command(label="Paste", command=self.paste_item)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Rename", command=self.rename_item)
        self.context_menu.add_command(label="Delete", command=self.delete_item)
        self.context_menu.add_separator()
        self.context_menu.add_command(label="Properties", command=self.show_properties)
    
    def load_directory(self, path):
        try:
            if not os.path.exists(path):
                messagebox.showerror("Error", f"Path does not exist: {path}")
                return
            
            if not os.path.isdir(path):
                messagebox.showerror("Error", "Not a directory")
                return
            
            self.current_path = os.path.abspath(path)
            self.path_var.set(self.current_path)
            
            # Clear current items
            for item in self.tree.get_children():
                self.tree.delete(item)
            
            # Load directory contents
            self.all_items = []
            try:
                items = os.listdir(self.current_path)
            except PermissionError:
                messagebox.showerror("Error", "Permission denied")
                return
            
            items.sort(key=lambda x: (not os.path.isdir(os.path.join(self.current_path, x)), x.lower()))
            
            for item in items:
                full_path = os.path.join(self.current_path, item)
                try:
                    stat_info = os.stat(full_path)
                    is_dir = os.path.isdir(full_path)
                    
                    size = self.format_size(stat_info.st_size) if not is_dir else "<DIR>"
                    file_type = "Folder" if is_dir else self.get_file_type(item)
                    modified = datetime.fromtimestamp(stat_info.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
                    
                    self.all_items.append({
                        'name': item,
                        'path': full_path,
                        'size': size,
                        'type': file_type,
                        'modified': modified,
                        'is_dir': is_dir
                    })
                except (PermissionError, OSError):
                    continue
            
            self.filter_files()
            self.update_status()
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load directory: {str(e)}")
    
    def filter_files(self):
        # Clear tree
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        search_term = self.search_var.get().lower()
        
        for item_data in self.all_items:
            if search_term in item_data['name'].lower():
                icon = "📁" if item_data['is_dir'] else "📄"
                self.tree.insert('', tk.END, text=f"{icon} {item_data['name']}", 
                               values=(item_data['size'], item_data['type'], item_data['modified']),
                               tags=(item_data['path'],))
    
    def format_size(self, size):
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024.0:
                return f"{size:.1f} {unit}"
            size /= 1024.0
        return f"{size:.1f} PB"
    
    def get_file_type(self, filename):
        ext = os.path.splitext(filename)[1].lower()
        types = {
            '.txt': 'Text File', '.pdf': 'PDF Document', '.doc': 'Word Document',
            '.docx': 'Word Document', '.xls': 'Excel Spreadsheet', '.xlsx': 'Excel Spreadsheet',
            '.py': 'Python Script', '.jpg': 'Image', '.jpeg': 'Image', '.png': 'Image',
            '.gif': 'Image', '.mp4': 'Video', '.mp3': 'Audio', '.zip': 'Archive',
            '.rar': 'Archive', '.exe': 'Executable', '.html': 'HTML File', '.css': 'CSS File',
            '.js': 'JavaScript File'
        }
        return types.get(ext, 'File')
    
    def on_double_click(self, event):
        self.open_item()
    
    def open_item(self):
        selection = self.tree.selection()
        if not selection:
            return
        
        item = self.tree.item(selection[0])
        path = item['tags'][0]
        
        if os.path.isdir(path):
            self.load_directory(path)
        else:
            # Open file with default application
            try:
                if platform.system() == 'Windows':
                    os.startfile(path)
                elif platform.system() == 'Darwin':  # macOS
                    os.system(f'open "{path}"')
                else:  # Linux
                    os.system(f'xdg-open "{path}"')
            except Exception as e:
                messagebox.showerror("Error", f"Cannot open file: {str(e)}")
    
    def go_back(self):
        # Simple back - just go up one level
        self.go_up()
    
    def go_up(self):
        parent = os.path.dirname(self.current_path)
        if parent != self.current_path:
            self.load_directory(parent)
    
    def go_home(self):
        self.load_directory(str(Path.home()))
    
    def refresh(self):
        self.load_directory(self.current_path)
    
    def create_folder(self):
        name = simpledialog.askstring("New Folder", "Enter folder name:")
        if name:
            new_path = os.path.join(self.current_path, name)
            try:
                os.makedirs(new_path)
                self.refresh()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to create folder: {str(e)}")
    
    def create_file(self):
        name = simpledialog.askstring("New File", "Enter file name:")
        if name:
            new_path = os.path.join(self.current_path, name)
            try:
                open(new_path, 'a').close()
                self.refresh()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to create file: {str(e)}")
    
    def copy_item(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "No item selected")
            return
        
        item = self.tree.item(selection[0])
        self.clipboard = item['tags'][0]
        self.clipboard_operation = 'copy'
        self.update_status(f"Copied: {os.path.basename(self.clipboard)}")
    
    def cut_item(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "No item selected")
            return
        
        item = self.tree.item(selection[0])
        self.clipboard = item['tags'][0]
        self.clipboard_operation = 'cut'
        self.update_status(f"Cut: {os.path.basename(self.clipboard)}")
    
    def paste_item(self):
        if not self.clipboard:
            messagebox.showwarning("Warning", "Nothing to paste")
            return
        
        try:
            name = os.path.basename(self.clipboard)
            dest = os.path.join(self.current_path, name)
            
            if os.path.exists(dest):
                if not messagebox.askyesno("Confirm", f"{name} already exists. Overwrite?"):
                    return
            
            if self.clipboard_operation == 'copy':
                if os.path.isdir(self.clipboard):
                    shutil.copytree(self.clipboard, dest, dirs_exist_ok=True)
                else:
                    shutil.copy2(self.clipboard, dest)
            elif self.clipboard_operation == 'cut':
                shutil.move(self.clipboard, dest)
                self.clipboard = None
                self.clipboard_operation = None
            
            self.refresh()
            self.update_status("Paste completed")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to paste: {str(e)}")
    
    def rename_item(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "No item selected")
            return
        
        item = self.tree.item(selection[0])
        old_path = item['tags'][0]
        old_name = os.path.basename(old_path)
        
        new_name = simpledialog.askstring("Rename", "Enter new name:", initialvalue=old_name)
        if new_name and new_name != old_name:
            new_path = os.path.join(os.path.dirname(old_path), new_name)
            try:
                os.rename(old_path, new_path)
                self.refresh()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to rename: {str(e)}")
    
    def delete_item(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "No item selected")
            return
        
        item = self.tree.item(selection[0])
        path = item['tags'][0]
        name = os.path.basename(path)
        
        if messagebox.askyesno("Confirm Delete", f"Are you sure you want to delete '{name}'?"):
            try:
                if os.path.isdir(path):
                    shutil.rmtree(path)
                else:
                    os.remove(path)
                self.refresh()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to delete: {str(e)}")
    
    def show_properties(self):
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Warning", "No item selected")
            return
        
        item = self.tree.item(selection[0])
        path = item['tags'][0]
        
        try:
            stat_info = os.stat(path)
            is_dir = os.path.isdir(path)
            
            info = f"Name: {os.path.basename(path)}\n"
            info += f"Path: {path}\n"
            info += f"Type: {'Folder' if is_dir else 'File'}\n"
            info += f"Size: {self.format_size(stat_info.st_size)}\n"
            info += f"Created: {datetime.fromtimestamp(stat_info.st_ctime).strftime('%Y-%m-%d %H:%M:%S')}\n"
            info += f"Modified: {datetime.fromtimestamp(stat_info.st_mtime).strftime('%Y-%m-%d %H:%M:%S')}\n"
            
            messagebox.showinfo("Properties", info)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to get properties: {str(e)}")
    
    def show_context_menu(self, event):
        # Select item under cursor
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)
            self.context_menu.post(event.x_root, event.y_root)
    
    def update_status(self, message=None):
        if message:
            self.status_bar.config(text=message)
        else:
            item_count = len(self.tree.get_children())
            self.status_bar.config(text=f"{item_count} items | {self.current_path}")


if __name__ == "__main__":
    root = tk.Tk()
    app = FileManager(root)
    root.mainloop()