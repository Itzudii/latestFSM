import os
import shutil
import sqlite3
import time
import uuid
import hashlib
from pathlib import Path


class TrashDB:
    def __init__(self, db_path="trash.db", trash_dir="Trash", retention_days=30):
        self.db_path = Path(db_path)
        self.trash_dir = Path(trash_dir)
        self.retention_days = retention_days

        self.trash_dir.mkdir(parents=True, exist_ok=True)
        self._init_db()

    # ------------------------
    # DB INIT
    # ------------------------
    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
            CREATE TABLE IF NOT EXISTS trash (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                uuid TEXT UNIQUE,
                name TEXT,
                original_path TEXT,
                trash_path TEXT,
                deleted_at INTEGER,
                size INTEGER,
                type TEXT,
                sha256 TEXT,
                state TEXT DEFAULT 'trashed'
            )
            """)

    # ------------------------
    # HASH (optional but safe)
    # ------------------------
    def _hash_file(self, path):
        if path.is_dir():
            return None
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()

    # ------------------------
    # PUT (SAFE DELETE)
    # ------------------------
    def put(self, path):
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(path)

        uid = str(uuid.uuid4())
        trash_path = self.trash_dir / uid

        meta = {
            "name": path.name,
            "original_path": str(path),
            "trash_path": str(trash_path),
            "deleted_at": int(time.time()),
            "size": path.stat().st_size,
            "type": "dir" if path.is_dir() else "file",
            "sha256": self._hash_file(path),
            "state": "trashed",
        }

        # 1️⃣ move file first
        shutil.move(str(path), str(trash_path))

        # 2️⃣ DB commit (atomic)
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                INSERT INTO trash
                (uuid, name, original_path, trash_path, deleted_at, size, type, sha256, state)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    uid, meta["name"], meta["original_path"], meta["trash_path"],
                    meta["deleted_at"], meta["size"], meta["type"],
                    meta["sha256"], meta["state"]
                ))
        except Exception:
            # rollback file move
            shutil.move(str(trash_path), str(path))
            raise

    # ------------------------
    # LIST (SAFE READ)
    # ------------------------
    def list(self, older_than_days=None):
        if older_than_days is None:
            cutoff = 0
        else:
            cutoff = int(time.time()) - (older_than_days * 86400)

        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute("""
            SELECT id, name, original_path, deleted_at, size, type
            FROM trash
            WHERE state='trashed' AND deleted_at <= ?
            ORDER BY deleted_at ASC
            """, (cutoff,))

            return [dict(zip([c[0] for c in cur.description], r))
                    for r in cur.fetchall()]

    # ------------------------
    # RESTORE (SAFE)
    # ------------------------
    def restore(self, trash_id):
        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute("""
            SELECT original_path, trash_path, sha256, type
            FROM trash WHERE id=? AND state='trashed'
            """, (trash_id,))
            row = cur.fetchone()

            if not row:
                return False

            original_path, trash_path, sha256, ftype = map(Path, row)

            original_path.parent.mkdir(parents=True, exist_ok=True)

            shutil.move(str(trash_path), str(original_path))

            # integrity check
            if sha256 and sha256 != self._hash_file(original_path):
                raise IOError("File corrupted during restore")

            conn.execute("""
            UPDATE trash SET state='restored' WHERE id=?
            """, (trash_id,))
            return True

    # ------------------------
    # AUTO PURGE (30+ DAYS)
    # ------------------------
    def purge(self):
        cutoff = int(time.time()) - (self.retention_days * 86400)

        with sqlite3.connect(self.db_path) as conn:
            cur = conn.execute("""
            SELECT id, trash_path, type FROM trash
            WHERE state='trashed' AND deleted_at <= ?
            """, (cutoff,))

            for tid, path, ftype in cur.fetchall():
                p = Path(path)
                if p.exists():
                    if ftype == "dir":
                        shutil.rmtree(p)
                    else:
                        p.unlink()

                conn.execute("DELETE FROM trash WHERE id=?", (tid,))
