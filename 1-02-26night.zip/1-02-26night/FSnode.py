import os
from FS.prifixSearch import Trie
from FS.extSearch import CustomHashMap
from FS.useful import filemode_readable,file_type,formate_sttime,name_ext
import logging
logger = logging.getLogger("FS")


class Node:
    def __init__(self,name,path,type_):
        self.path = path
        self.name = name
        self.type = type_

        self.childs = {} if self.type == 'd' else None
        self.prifixSearch = Trie() if self.type == 'd' else None
        self.extensionSearch =  CustomHashMap() if self.type == 'd' else None

        self.state = "indexed"
        self.indicator = "sync"
        self.islocked = False
        self.locked_hash = None


        self.details = name_ext(name)

        self.hash = None
        self.vector = None
        self.tags = None

        self.size = None
        self.modified_time = None
        self.created_time = None
        self.mode = None

    def _config_stat(self,st):

        self.size = st.st_size
        self.modified_time = st.st_mtime
        self.created_time = st.st_ctime
        self.mode = st.st_mode      
    
    def config_by_path(self,path):
        st = os.stat(path)
        self._config_stat(st)

    def add(self, node):
        if self.childs is None:
            raise TypeError("Cannot add child to non-directory")

        self.childs[node.name] = node

        if self.prifixSearch:
            self.prifixSearch.insert(node.name, node.path)

        if node.type == 'f' and self.extensionSearch:
            self.extensionSearch.insert(node.name, node.path)

    def _add_file_to_search_structure(self,node):
        self.prifixSearch.insert(node.name,node.path)
        self.extensionSearch.insert(node.name,node.path)

    def _add_dir_to_search_structure(self,node):
        self.prifixSearch.insert(node.name,node.path)
    # def remove(self, name):
    #     if self.childs is None:
    #         return None

    #     node = self.childs.pop(name, None)
    #     if not node:
    #         return None

    #     if self.prifixSearch:
    #         self.prifixSearch.delete(node.name, node.path)

    #     if node.type == 'f' and self.extensionSearch:
    #         self.extensionSearch.delete(node.name, node.path)

    #     return node

    def get(self,name,alter = None):
        if name in self.childs:
            return self.childs[name]
        return alter

    
    def _del_file_to_search_structure(self,node):
        if self.prifixSearch is None :
            return False
        self.prifixSearch.delete(node.name,node.path)
        self.extensionSearch.delete(node.name,node.path)
        return True

    def _del_dir_to_search_structure(self,node):
        if self.prifixSearch is None :
            return False
        self.prifixSearch.delete(node.name,node.path)
        return True


    def search_prifix(self,prifix):
        return self.prifixSearch.search_by_prefix(prifix)

    def search_ext(self,ext):
        return self.extensionSearch.get_by_extension(ext)


    def to_dict(self):
        return {
            'name': self.name,
            'path': self.path,
            'indicator': self.indicator,
            'type': self.type,
            'size': self.size,
            'modified_time': self.modified_time,
            'created_time': self.created_time,
            'mode': self.mode,
        } 
    
    def __repr__(self):
        return f"Node(name={self.name}, path={self.path}, type={self.type})"

