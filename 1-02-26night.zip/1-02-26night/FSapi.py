from FScontroller import Controller
import webview
from FS.useful import get_indicator
from FS.icon import known_file_types

class API:
    def __init__(self, controller: Controller):
        self.ctrl = controller

    def show_list(self):
        data= self.ctrl.fs.show_list()
        print(self.ctrl.fs.cwd.childs)
        result = []
        for node in data:
            result.append({
                "path":node.path,
                "name":node.name,
                "date":node.modified_time,
                "type":node.type,
                "size":node.size,
                "indicator":get_indicator(node.indicator),
                "filetype":known_file_types.get(f'.{node.details['ext']}',"unknown"),
                "islock":node.islocked,
                "ishidden":node.details['ishidden'],
                "icon":'<svg xmlns="http://www.w3.org/2000/svg" height="30px" viewBox="0 -960 960 960" width="30px" fill="#fff"><path d="m484-288 89-68 89 68-34-109.15L717-468H607.56L573-576l-34 108H429l89 70.85L484-288Zm-316 96q-29 0-50.5-21.5T96-264v-432q0-29.7 21.5-50.85Q139-768 168-768h216l96 96h312q29.7 0 50.85 21.15Q864-629.7 864-600v336q0 29-21.15 50.5T792-192H168Zm0-72h624v-336H450l-96-96H168v432Zm0 0v-432 432Z"/></svg>' if node.type == 'd' else '<svg xmlns="http://www.w3.org/2000/svg" height="20px" viewBox="0 -960 960 960" width="20px" fill="#e3e3e3"><path d="M263.72-96Q234-96 213-117.15T192-168v-624q0-29.7 21.15-50.85Q234.3-864 264-864h312l192 192v504q0 29.7-21.16 50.85Q725.68-96 695.96-96H263.72Zm.28-72h432v-456H528v-168H264v624Zm203.54-24q65.52 0 110.99-45.5T624-348v-132h-72v132q0 34.65-24.5 59.33Q503-264 467.51-264q-34.45 0-58.98-24.67Q384-313.35 384-348v-180q0-10 7.2-17t16.8-7q10 0 17 7t7 17v192h72v-192q0-40.32-27.77-68.16-27.78-27.84-68-27.84Q368-624 340-596.16q-28 27.84-28 68.16v180q0 65 45.5 110.5T467.54-192ZM264-792v189-189 624-624Z"/></svg>'
            })
        return result

    def open(self,name):
        self.ctrl.fs.go_to(name)

    def backward(self):
        self.ctrl.fs.go_back()

    def forward(self):
        self.ctrl.fs.go_forward()

    def go_root(self):
        self.ctrl.fs.go_to_root()


    def rename(self,old,new):
        return self.ctrl.fs.rename(old,new)
        

    def cut(self,data):
        self.ctrl.fs.unselect_all()
        for filename in data:
            self.ctrl.fs.select_name(filename)
        self.ctrl.fs.cut()

    def copy(self,data):
        self.ctrl.fs.unselect_all()
        for filename in data:
            self.ctrl.fs.select_name(filename)
        self.ctrl.fs.copy()
        
    def paste(self):
        return self.ctrl.fs.paste()

    def delete(self,data):
        self.ctrl.fs.unselect_all()
        for filename in data:
            self.ctrl.fs.delete(filename)



        

    

if __name__ == '__main__':
    api = API(Controller())

    w1 = webview.create_window(
    title="FS Manager",
    url="frontend/main-window.html",
    width=1200,
    height=700,
    resizable=True,
    fullscreen=False,
    js_api=api
    )

    webview.start(debug=True)
