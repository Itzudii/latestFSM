#!/usr/bin/env python
"""
Test script to verify the polished file management system functionality.
Tests DB connection, tree loading, and basic operations.
"""

import os
import sys
from FSstorage import Storage
from FSmain import FSManager
import queue

def test_db_connection():
    """Test database connection and table creation."""
    print("=" * 60)
    print("TEST 1: Database Connection")
    print("=" * 60)
    try:
        storage = Storage("save/fs_index.db")
        print("✓ Database connected successfully")
        
        # Check if tables exist
        storage.cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = storage.cursor.fetchall()
        print(f"✓ Found {len(tables)} table(s): {[t[0] for t in tables]}")
        
        return storage
    except Exception as e:
        print(f"✗ Database connection failed: {e}")
        return None

def test_tree_loading(storage):
    """Test tree loading from database."""
    print("\n" + "=" * 60)
    print("TEST 2: Tree Loading from Database")
    print("=" * 60)
    try:
        db_queue = queue.PriorityQueue()
        fs = FSManager(storage, [], [], [], db_queue)
        
        if fs.root:
            print(f"✓ Tree root loaded: '{fs.root.name}'")
            print(f"✓ Root ID: {fs.root.id}")
            
            if fs.root.childs:
                print(f"✓ Root has {len(fs.root.childs)} children")
                # Show first 5 children
                for i, (name, child) in enumerate(list(fs.root.childs.items())[:5]):
                    type_str = "DIR" if child.is_dir else "FILE"
                    print(f"  - {name} ({type_str})")
                if len(fs.root.childs) > 5:
                    print(f"  ... and {len(fs.root.childs) - 5} more")
            else:
                print("⚠ Root has no children (empty tree)")
            
            return fs
        else:
            print("✗ Tree root is None")
            return None
            
    except Exception as e:
        print(f"✗ Tree loading failed: {e}")
        import traceback
        traceback.print_exc()
        return None

def test_id_to_node_map(fs):
    """Test id_to_node mapping."""
    print("\n" + "=" * 60)
    print("TEST 3: ID to Node Mapping")
    print("=" * 60)
    try:
        if fs.id_to_node:
            print(f"✓ id_to_node map created with {len(fs.id_to_node)} nodes")
            
            # Verify root is in map
            if fs.root.id in fs.id_to_node:
                print(f"✓ Root node found in map (ID: {fs.root.id})")
            else:
                print("✗ Root node NOT in map")
                
            # Test path generation
            if fs.root.childs:
                first_child = list(fs.root.childs.values())[0]
                path = fs.get_path(first_child.id)
                print(f"✓ Path generation works: {path}")
        else:
            print("✗ id_to_node map is empty")
            
    except Exception as e:
        print(f"✗ ID mapping test failed: {e}")

def test_db_queries(storage):
    """Test database query functions."""
    print("\n" + "=" * 60)
    print("TEST 4: Database Queries")
    print("=" * 60)
    try:
        # Count total nodes
        storage.cursor.execute("SELECT COUNT(*) FROM nodes")
        count = storage.cursor.fetchone()[0]
        print(f"✓ Total nodes in DB: {count}")
        
        # Count by type
        storage.cursor.execute("SELECT type, COUNT(*) FROM nodes GROUP BY type")
        type_counts = storage.cursor.fetchall()
        for type_, cnt in type_counts:
            type_name = "Directories" if type_ == 'd' else "Files"
            print(f"  - {type_name}: {cnt}")
            
        # Test prefix search
        results = storage.search_prefix("test", limit=5)
        print(f"✓ Prefix search for 'test': {len(results)} results")
        
    except Exception as e:
        print(f"✗ Database query test failed: {e}")

def main():
    """Run all tests."""
    print("\n" + "=" * 60)
    print("FILE MANAGEMENT SYSTEM - FUNCTIONALITY TEST")
    print("=" * 60 + "\n")
    
    # Test 1: DB Connection
    storage = test_db_connection()
    if not storage:
        print("\n✗ CRITICAL: Database connection failed. Aborting tests.")
        return
    
    # Test 2: Tree Loading
    fs = test_tree_loading(storage)
    if not fs:
        print("\n✗ CRITICAL: Tree loading failed. Aborting remaining tests.")
        return
    
    # Test 3: ID Mapping
    test_id_to_node_map(fs)
    
    # Test 4: DB Queries
    test_db_queries(storage)
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    print("✓ All critical tests passed!")
    print("✓ Database is functioning correctly")
    print("✓ Tree generation from DB is working")
    print("✓ Project is ready for use")
    print("\nTo start the GUI application, run: python FSapi.py")
    print("=" * 60 + "\n")

if __name__ == "__main__":
    main()
