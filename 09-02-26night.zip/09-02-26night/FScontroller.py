import webview
import threading
import time
from queue import Queue
import os


from FSTags import TagGenerator
from FSmain import FSManager
from FSCLI import CLI

from FSvector import MrVectorExpert
from FSlog_config import setup_logger

from FSgui import FSProjectGUI


class Controller:
    def __init__(self) -> None:
        self.isBgRunning = True
        self.isRunning = True
        self.last_input = None

        self.vec = MrVectorExpert()
        # self.vec.load_model()
        self.vec.load()
   
        self.tag = TagGenerator()

        self.fs = FSManager(self.tag,self.vec)
        self.fs.load()

        self.cli = CLI(self.fs)

        

        self.t2 = threading.Thread(target=self.background_worker, daemon=True)

        self.t2.start()


    def background_worker(self):
        # refresh_gen = self.fs._refresh(self.fs.root)
        print("background worker started")
        self.fs.startup()
    
        while self.isRunning:
            
            if not self.isBgRunning:
                time.sleep(1)
                # user_input = self.task_queue.get()
                # self.process_user_task(user_input)
                continue
            # print("background worker loop")

            
            # 1 refresh step
            # try:
            #     next(refresh_gen)
            # except StopIteration:
            #     pass

            self.fs.active()
        
            # 1 index step
            self.fs.background_index_step1()

            # 2 index step
            self.fs.background_index_step2()
    
            # 1 vector DB maintenance step
            self.fs.mrvec.background_task_step()
    
            # time.sleep(0.003)
            time.sleep(0.1)

