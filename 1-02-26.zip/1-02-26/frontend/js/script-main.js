let currentView = 'grid';
let selectedFiles = new Set();
let detailsPanelOpen = false;
let detailsPanelautoOpen = false;
let files = null;

async function refresh(){
    files = await window.pywebview.api.show_list();
    await renderFiles();
    await updateDetailsPanel();
}

async function renderFiles() {
        const gridContent = document.getElementById('gridContent');
        const gridHeader = document.getElementById('gridHeader');
        
        console.log("data");
        console.log(files);

        if (currentView === 'list') {
            gridContent.className = 'grid-content list-view';
            gridHeader.style.display = 'grid';
            gridContent.innerHTML = files.map((file, index) => `
                        <div class="file-item-list ${selectedFiles.has(index) ? 'selected' : ''}" 
                             onclick="selectFile(${index}, event)" 
                             oncontextmenu="showContextMenu(event, ${index})"
                             ondblclick="openFileHandler('${file.name}')">
                            <div class="file-info">
                                <div class="file-icon-list">${file.icon}</div>
                                <div class="file-details">
                                    <div class="file-name">${file.name}</div>
                                    <div class="file-type">${file.type}</div>
                                </div>
                            </div>
                            <div class="file-size">${file.size}</div>
                            <div class="file-date">${file.date}</div>
                            <div class="file-typeD">${file.filetype}</div>
                            <div class="file-state file-indicator-grid">${file.indicator}</div>
                        </div>
                    `).join('');
        } else {
            gridContent.className = 'grid-content grid-view';
            gridHeader.style.display = 'none';
            gridContent.innerHTML = files.map((file, index) => `
                       <div class="file-item-grid ${selectedFiles.has(index) ? 'selected' : ''}" 
                             onclick="selectFile(${index}, event)" 
                             oncontextmenu="showContextMenu(event, ${index})"
                             ondblclick="openFileHandler('${file.name}')">
                            <div class="file-icon-grid-div">
                                <div></div>
                               <div class="file-icon-grid">${file.icon}</div>
                                <div class="file-indicator-grid">${file.indicator}</div>
                            </div>
                           <div class="file-name-grid">${file.name}</div>
                        </div>
            `).join('');
        }
    }
// Switch view
function switchView(view) {
    currentView = view;
    document.querySelectorAll('.view-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    renderFiles();
}

async function updateDetailsPanel() {
    if (selectedFiles.size === 0) {
        // No file selected
        document.getElementById('detailsIconLarge').textContent = '📄';
        document.getElementById('detailsFileName').textContent = 'Select a file';
        document.getElementById('detailsFileType').textContent = 'No file selected';
        document.getElementById('detailsSize').textContent = '-';
        document.getElementById('detailsLocation').textContent = '-';
        document.getElementById('detailsCreated').textContent = '-';
        document.getElementById('detailsModified').textContent = '-';
        document.getElementById('detailsOwner').textContent = '-';
        document.getElementById('detailsStorageSection').style.display = 'none';
    } else {
        // Get first selected file
        const fileIndex = Array.from(selectedFiles)[0];
        const file = files[fileIndex];

        // Update preview
        document.getElementById('detailsIconLarge').textContent = file.icon;
        document.getElementById('detailsFileName').textContent = file.name;
        document.getElementById('detailsFileType').textContent = file.type;

        // Update general info
        document.getElementById('detailsSize').textContent = file.size;
        document.getElementById('detailsLocation').textContent = file.path;
        document.getElementById('detailsCreated').textContent = file.created;
        document.getElementById('detailsModified').textContent = file.date;
        document.getElementById('detailsOwner').textContent = file.owner;

        // Show/hide storage section for folders
        const storageSection = document.getElementById('detailsStorageSection');
        if (file.isFolder) {
            storageSection.style.display = 'block';
            document.getElementById('detailsTotalSize').textContent = file.size;
            document.getElementById('detailsItemCount').textContent = file.itemCount || '-';

            // Random progress for demo
            const progress = Math.floor(Math.random() * 40 + 50);
            document.getElementById('detailsProgressBar').style.width = progress + '%';
        } else {
            storageSection.style.display = 'none';
        }
    }
}

function toggleDetailsPanel() {
    const panel = document.getElementById('detailsPanel');
    detailsPanelOpen = !detailsPanelOpen;

    if (detailsPanelOpen) {
        panel.classList.add('show');
    } else {
        panel.classList.remove('show');
    }
}
// Select File
function selectFile(index, event) {
    if (event.ctrlKey || event.metaKey) {
        if (selectedFiles.has(index)) {
            selectedFiles.delete(index);
        } else {
            selectedFiles.add(index);
        }
    } else {
        selectedFiles.clear();
        selectedFiles.add(index);
    }
    renderFiles();
    updateDetailsPanel();

    // Auto-open details panel if a file is selected
    if (selectedFiles.size > 0 && !detailsPanelOpen && detailsPanelautoOpen) {
        toggleDetailsPanel();
    }
}

async function openFileHandler(fileName) {
    console.log('Opening:', fileName);
    // alert(`Opening: ${fileName}`);
    await window.pywebview.api.open(fileName);
    refresh();
}
async function goBack() {
    console.log('Going back');
    await window.pywebview.api.backward();
    refresh();
}

async function goForward() {
    console.log('Going forward');
    await window.pywebview.api.forward();
}

async function goUp() {
    console.log('Going up');
    // window.pywebview.api.go_root()
}


window.addEventListener("pywebviewready", refresh)