from llama_cpp import Llama

# -------- MODEL PATHS (FULL PATHS REQUIRED) --------
QWEN_MODEL_PATH = r"model\qwen2.5-1.5b-instruct-q8_0.gguf"
LLAMA_MODEL_PATH = r"model\llama-2-7b-chat.Q4_K_M.gguf"

# -------- LOAD MODELS (ONCE) --------
qwen = Llama(
    model_path=QWEN_MODEL_PATH,
    n_ctx=4096,
    n_threads=8,   # adjust to your CPU
    verbose=False
)

llama = Llama(
    model_path=LLAMA_MODEL_PATH,
    n_ctx=4096,
    n_threads=8,
    verbose=False
)

# -------- COMMON RUN FUNCTION --------
def run_model(llm, prompt, max_tokens=512, temp=0.3):
    output = llm(
        prompt,
        max_tokens=max_tokens,
        temperature=temp,
        stop=["</s>"]
    )
    return output["choices"][0]["text"].strip()


# -------- STAGE 1: QWEN (STRUCTURE) --------
def extract_key_points(text):
    prompt = f"""
You are an expert teacher.

Task:
Extract only important exam-relevant points from the text.
Use ONLY the given text.
Do NOT add explanations.

Return as a numbered list.

Text:
\"\"\"
{text}
\"\"\"
"""
    return run_model(qwen, prompt, max_tokens=400, temp=0.2)


# -------- STAGE 2: LLAMA (QUESTIONS) --------
# def generate_questions(points):
#     prompt = f"""
# You are an exam paper setter.

# Using ONLY the points below, generate:
# - short-answer questions
# - long-answer question

# Rules:
# - No outside knowledge
# - Clear exam language
# - Avoid repetition

# Points:
# \"\"\"
# {points}
# \"\"\"
# """
#     return run_model(llama, prompt, max_tokens=600, temp=0.4)

def generate_questions(points):
    prompt = f"""
SYSTEM:
You are an exam paper generator.
You MUST generate questions.
You MUST NOT ask the user to do anything.

TASK:
Generate exactly:
1. ten MCQs


RULES:
- Use ONLY the points below
- Do NOT add new information
- Do NOT explain
- Do NOT ask questions
- Output questions directly

POINTS:
{points}

OUTPUT:
"""
    return run_model(llama, prompt, max_tokens=600, temp=0.25)
# 2. five short-answer questions
# 3. three long-answer question

# -------- MAIN PIPELINE --------
def generate_exam_questions(text):
    key_points = extract_key_points(text)
    questions = generate_questions(key_points)

    return {
        "key_points": key_points,
        "questions": questions
    }


# -------- TEST --------
if __name__ == "__main__":
    sample_text = """
    Operating systems act as an interface between computer hardware and the user.
They are responsible for managing hardware resources efficiently and ensuring
that application programs execute correctly. The primary resources managed by
an operating system include the CPU, main memory, secondary storage, and input/output devices.

The CPU management function of an operating system involves process scheduling.
Processes are programs in execution, and the operating system decides which
process runs on the CPU and for how long. Scheduling algorithms such as First Come
First Served (FCFS), Shortest Job First (SJF), Priority Scheduling, and Round Robin
are used to achieve fairness and efficiency. Context switching allows the CPU to
switch from one process to another, enabling multitasking.

Memory management is another critical responsibility of an operating system.
The operating system keeps track of which parts of memory are in use and which
are free. It allocates memory to processes when required and deallocates it
when the process terminates. Techniques such as paging and segmentation are
used to manage memory efficiently. Virtual memory allows programs to execute
even if they are not fully loaded into physical memory.

File system management enables the operating system to organize data on storage
devices. Files are logical units of information, and directories are used to
group related files. The operating system provides operations such as file
creation, deletion, reading, writing, and permission management. Different file
allocation methods like contiguous, linked, and indexed allocation are used
to store files on disk.

Input/output management handles communication between the system and external
devices. Device drivers act as intermediaries between the operating system and
hardware devices. Buffering, caching, and spooling techniques are used to
improve I/O performance and efficiency.

The kernel is the core component of an operating system. It runs in privileged
mode and has complete access to system resources. The kernel is responsible
for process management, memory management, device management, and system calls.
System calls provide an interface through which user programs can request
services from the operating system.

Operating systems can be classified into different types based on their usage.
Batch operating systems execute jobs in batches without user interaction.
Time-sharing operating systems allow multiple users to interact with the system
simultaneously. Real-time operating systems are designed to respond to inputs
within strict time constraints. Distributed operating systems manage a group
of independent computers and make them appear as a single system.

Security and protection are essential aspects of operating system design.
The operating system ensures that unauthorized users do not access system
resources. Authentication, authorization, and access control mechanisms are
used to protect data and processes. Protection mechanisms prevent one process
from interfering with another process.

Modern operating systems also support virtualization, which allows multiple
operating systems to run on a single physical machine. Virtual machines are
managed by a hypervisor, which allocates hardware resources to each virtual
environment. Virtualization improves resource utilization and system isolation.

    """

    result = generate_exam_questions(sample_text)

    print("\n=== KEY POINTS ===\n")
    print(result["key_points"])

    print("\n=== QUESTIONS ===\n")
    print(result["questions"])
