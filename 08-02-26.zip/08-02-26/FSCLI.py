import threading
import time
from queue import Queue
import os
from FS.useful import filemode_readable,formate_sttime
import logging
logger = logging.getLogger("FS")
class CLI:
    def __init__(self,fs) -> None:
        self.fs = fs
        self.isRunning = True
        self.last_input = None

        self.task_queue = Queue()

    def clear(self):
        os.system('cls')

   
    
    def _ls(self,command):
        base = command.split()
        if len(base) == 1:
            return f'{'\n'.join(list(self.fs.cwd.childs.keys()))}'
        else:
            print(f'not a valid command , what do you mean by- -->[{base[1]}]')

    def _cd(self,command):
        try:
            c,name = command.strip().split(" ",1)
            if name == './':
                self.fs.go_back()
                return ''
            else:
                isDone = self.fs.go_to(name)
                return f'{name} not found' if isDone else ""
        except Exception:
            return 'try help for cd'


    def _pwd(self,command):
        base = command.split()
        if len(base) == 1:
            print("active",self.fs.cwd.path)
            return f'{self.fs.cwd.path}'
        else:
           return f'not a valid command , what do you mean by- -->[{base[1]}]'

    def _prd(self,command):
        base = command.split()
        if len(base) == 1:
            return f'{self.fs.root.path}'
        else:
              return f'not a valid command , what do you mean by- -->[{base[1]}]'
    

    def _refresh(self,command):
        base = command.split()
        len_ = len(base)
        if len_ == 1:
            self.fs.refresh_cwd()
            return ''
        elif len_ == 2 and base[1] == '--deep':
            self.fs.refresh_root()
            return f'full refresh from root:{self.fs.root.path}'
        else:
            print(f'not a valid command , what do you mean by- -->[{base[1]}]')
      
    

    def _open(self,command):
        try:
            c,path = command.strip().split(" ",1)
            self.fs._open_file_with_default_app(path)
        except Exception as e:
            return f'{e}'
    

    def _cut(self,command):
        return 'not avaliable yet'
    

    def _copy(self,command):
        return 'not avaliable yet'
    

    def _del(self,command):
        try:
            c,path = command.strip().split(" ",1)
        except Exception as e:
            return f"{command} not valid"

        data = self.fs.get_node_by_path(path)
        node = data['result']
        msg = data['message']
        if node:
            self.fs.delete_node(node)
            return ''
        else:
            return f'{msg}, use "/" in place of "\\" if have'

    

    def _mkdir(self,command):
        try:
            c,path = command.strip().split(" ",1)
            os.makedirs(path)
        except Exception as e:
            return f"{e}"
       

    def _mkf(self,command):
        try:
            c,path,content = command.strip().split(" ",2)
        except Exception as e:
            return f"{command} not valid try help for command"

        try:
            self.fs._write_content_to_file(path,content)
        except Exception as e:
            return f"{e}"

    
    def _append(self,command):
        try:
            c,path,content = command.strip().split(" ",2)
        except Exception as e:
            return f"{command} not valid try help for command"

        try:
            self.fs._append_content_to_file(path,content)
        except Exception as e:
            return f"{e}"
    

    def _info(self,command):
        try:
            c,path = command.strip().split(" ",1)
            data = self.fs.get_node_by_path(path)
            node = data['result']
            msg = data['message']
            if node:
                return f'\npath: {node.path}\nname: {node.name}\nchilds: {node.childs}\ntype: {node.type}\nstate: {node.state}\ninner_state: {node.inner_state}\nislocked: {node.islocked}\nlock_hash: {node.lock_hash}\nhash: {node.hash}\nvector: {node.vector}\ntags: {node.tags}\nsize: {node.size}\nmodified_time: {formate_sttime(node.modified_time)}\ncreated_time: {formate_sttime(node.created_time)}\nmode: {filemode_readable(node.mode)}'
            else:
                return msg
          
        except Exception as e:
            return f"{e}"
    

    def _rename(self,command):
        return 'not avaliable yet'
    

    def _tree(self,command):
        return 'not avaliable yet'
    

    def _search(self,command):
        return 'not avaliable yet'
    

    def _find(self,command):
        try:
            c,path = command.strip().split(" ",1)
            data = self.fs.get_node_by_path(path)
            node = data['result']
            msg = data['message']
            if node:
                paths = self.fs.search_paths_by_hash(node.hash)
                return f'total:{len(paths)}\n{'\n'.join(paths)}' if paths else 'total:0\nnot duplicate found'
            else:
                return msg
          
        except Exception as e:
            return f"{e}"
        


    def _tag(self,command):
        try:
            c,path = command.strip().split(" ",1)
            data = self.fs.get_node_by_path(path)
            node = data['result']
            msg = data['message']
            if node:
                tags = self.fs.tagG.generate_tags_path(path)
                return ' '.join(tags)
            else:
                return msg
          
        except Exception as e:
            return f"{e}"
    

    def _verify(self,command):
        try:
            c,path = command.strip().split(" ",1)
            data = self.fs.get_node_by_path(path)
            node = data['result']
            msg = data['message']
            if node:
                data = self.fs.is_corupted(node)
                return  data['status']
            else:
                return msg
          
        except Exception as e:
            return f"{e}"

    def _hash(self,command):
        try:
            c,path = command.strip().split(" ",1)
            data = self.fs.get_node_by_path(path)
            node = data['result']
            msg = data['message']
            if node:
                return  node.hash
            else:
                return msg
          
        except Exception as e:
            return f"{e}"
    

    def _dup(self,command):
        base = command.split()
        if len(base) == 1:
            data = self.fs.search_duplicate_files()
            string = ''
            for hash_,paths in data.items():
                string += f'hash:{hash_}\n   |--->{'\n   |--->'.join(paths)}\n\n'
            return string
        else:
            print(f'not a valid command , what do you mean by- -->[{base[1]}]')
        
    
    def _status(self,command):
        base = command.split()
        if len(base) == 1:
            return self.fs._status()

        else:
            print(f'not a valid command , what do you mean by- -->[{base[1]}]')
    

    def _stats(self,command):
        base = command.split()
        if len(base) == 1:
            return self.fs._stats()

        else:
            print(f'not a valid command , what do you mean by- -->[{base[1]}]')

    def _help(self):
        return '''
        
        '''
        
    


    

    def process_user_task(self,command):
        base = command.split()[0]
        
        commands = {
            "ls":self._ls,
            "cd":self._cd,
            "pwd":self._pwd,
            "prd":self._prd,
            "refresh":self._refresh,
            "open":self._open,
            "cut":self._cut,
            "copy":self._copy,
            "del":self._del,
            "mkdir":self._mkdir,
            "mkf":self._mkf,
            "append":self._append,
            "info":self._info,
            "rename":self._rename,
            "tree":self._tree,
            "search":self._search,
            "find":self._find,
            "tag":self._tag,
            "verify":self._verify,
            "hash":self._hash,
            "dup":self._dup,
            "status":self._status,
            "stats":self._stats,
            "help":self._help
        }
        output = commands.get(base, lambda c: f'{c} not found')(command)

        if output is not None:
            return output 
        return 'output is not catch! error in inbuild methods'


    def h(self,command):# all work put robustness//////////////////////////
        if command == 'quit':
            self.isRunning = False
        elif command.startswith('cd '):
            _,name = command.split(' ',1)
            self.fs.go_to(name)
        elif command == 'back':
            self.fs.go_back()
        elif command == 'root':
            self.fs.go_to_root()
        elif command == 'refresh':
            self.fs.refresh_cwd()
        elif command == 'refreshall':
            self.fs.refresh_root()
        elif command == 'selectall':
            self.fs.select_all()
        elif command.startswith('select'):
            _,name = command.split(' ',1)
            node = self.fs.get_node(name)
            if node:
                self.fs.select(node)
            else:
                print(f"{name} not found in current directory")
        elif command == "unselectall":
            self.fs.unselect_all()
        elif command.startswith('unselect'):
            _,name = command.split(' ',1)
            node = self.fs.get_node(name)
            if node:
                self.fs.unselect(node)
            else:
                print(f"{name} not found in current directory")
        elif command.startswith('open'):
            _,name = command.split(' ',1)
            node = self.fs.get_node(name)
            if node:
                self.fs.open(node)
            else:
                print(f"{name} not found in current directory")
        elif command == 'cut':
            self.fs.cut()
        elif command == 'copy':
            self.fs.copy()
        elif command == 'paste':
            self.fs.paste()
        elif command.startswith('del'):
            _,name = command.split(' ',1)
            node = self.fs.get_node(name)
            if node:
                self.fs.delete(node)
            else:
                print(f"{name} not found in current directory")
        elif command.startswith('mkdir'):
            _,name = command.split(' ',1)
            self.fs.create_dir(name)
        elif command.startswith('mkf'):
            _,name,content = command.split(' ',2)
            self.fs.create_file(name,content) 
        elif command.startswith('rename'):
            _,old_name,new_name = command.split(' ',2)
            node = self.fs.get_node(old_name)
            if node:
                self.fs.rename(new_name,node)
            else:
                print(f"{old_name} not found in current directory")
        elif command.startswith('write'):
            _,name,content = command.split(' ',2)
            node = self.fs.get_node(name)
            if node:
                self.fs.write_to_file(node,content)
            else:
                print(f"{name} not found in current directory")
        elif command.startswith('append'):
            _,name,content = command.split(' ',2)
            node = self.fs.get_node(name)
            if node:
                self.fs.append_to_file(node,content)
            else:
                print(f"{name} not found in current directory")
        elif command.startswith('search'):
            _,typ,mood,content = command.split(' ',3)
            res = []
            if typ == '-p':
                if mood == '-nf':
                    res = self.fs.search_prifix(content,'f')
                elif mood == '-af':
                    res = self.fs.search_prifix_all(content,'f')
                if mood == '-nd':
                    res = self.fs.search_prifix(content,'d')
                elif mood == '-ad':
                    res = self.fs.search_prifix_all(content,'d')
                else:
                    print("mood is invalid")
            elif typ == '-e':
                if mood == '-n':
                    res = self.fs.search_ext(content)
                elif mood == '-a':
                    res = self.fs.search_ext_all(content)
                else:
                    print("mood is invalid")
            else:
                    print("type is invalid")
     
    
    def  display(self):
        print("=== File Management System ===")
        print("_"*100)
        print(f'|Current Directory: {self.fs.cwd.path:79}|')
        print("_"*100)

        lst = self.fs.show_list()
        for item in lst:
            print(f'{item["name"]:40}{item["type"]:10}{item["size"]:<10}{item['path']}')

        print("_"*100)
        for item in self.fs.selected_nodes:
            print(f'|:       {item.name:90}|')
        print("_"*100)

                
    """
    tread funtions \/
    """
    def run_command(self,command):
            logger.info(f"[INPUT CAPTURED] -> {command}")
            self.last_input = command
            self.task_queue.put(command)


                
    def background_worker(self):
        refresh_gen = self.fs._refresh(self.fs.root)
    
        while self.isRunning:
            
            if not self.task_queue.empty():
                user_input = self.task_queue.get()
                self.process_user_task(user_input)
                continue

            
            # 1 refresh step
            try:
                next(refresh_gen)
            except StopIteration:
                pass
        
            # 1 index step
            self.fs.background_index_step1()

            # 2 index step
            self.fs.background_index_step2()
    
            # 1 vector DB maintenance step
            self.fs.mrvec.background_task_step()
    
            # time.sleep(0.003)
            time.sleep(0.1)
