import threading
import time
from queue import Queue, Empty

from FSTags import TagGenerator
from FSmain import FSManager
from FSCLI import CLI
from FSvector import MrVectorExpert
from FStask import TaskPerformer


class Controller:

    def __init__(self):

        self.task_Queue = Queue()
        self.result_Queue = Queue()
        self.isRunning = True

        self.vec = MrVectorExpert()
        self.vec.load()

        self.tag = TagGenerator()

        self.fs = FSManager(self.tag, self.vec)
        self.fs.load()

        self.cli = CLI(self.fs)

        # Task performer
        self.performer = TaskPerformer(self.fs)

        self.t2 = threading.Thread(
            target=self.fs_background,
            daemon=True
        )
        self.t2.start()

    def kill_background(self):
        self.isRunning = False

    def fs_background(self):

        print("background worker started")
        self.fs.startup()

        while self.isRunning:

            try:
                task = self.task_Queue.get_nowait()
                result = self.task_handler(task)
                self.result_Queue.put(result)
                continue

            except Empty:
                pass

            self.fs.active()
            self.fs.background_index_step1()
            self.fs.background_index_step2()
            self.fs.mrvec.background_task_step()

            time.sleep(0.001)

    def task_handler(self, task):

        target = task.get("for")
        name = task.get("name")
        args = task.get("args", [])

        if target == "TaskPerformer":
            fn = getattr(self.performer, name)
            return fn(*args)

        return {"error": "unknown task"}

    def start_task(self, task):

        self.task_Queue.put(task)

        while True:
            try:
                return self.result_Queue.get_nowait()
            except Empty:
                pass

            time.sleep(0.001)
