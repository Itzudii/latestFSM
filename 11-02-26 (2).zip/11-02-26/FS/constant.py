DEFAULT_PATH = "d:/don'tDelete/Desktop/file management system"
DEFAULT_NAME = "file management system"
# DEFAULT_PATH = "d:/don'tDelete/Desktop/file management system/testnew"
# DEFAULT_NAME = "testnew"
ALLOWED_TAGS_EXT = ['txt','pdf','doc','docx']
COSINE_SIMILARITY_MINVALUE = 0.6
INDICATOR = {
    "modified":"ORANGE",
    "lock_m":"RED",
    "sync":"GREEN"
}