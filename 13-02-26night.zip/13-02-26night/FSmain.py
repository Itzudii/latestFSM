from operator import itemgetter
from FS.constant import DEFAULT_NAME,DEFAULT_PATH,ALLOWED_TAGS_EXT
from FS.stack import Stack
from FS.prifixSearch import Trie
from FS.hash import HashMaster
from FS.extSearch import CustomHashMap
from FS.fileReader import universal_reader
from FS.useful import needs_rehash,file_hash,name_ext,filename_dup_normalizer
from FS.cusq import Que
from FS.cus_dict import pickle_dict
from FSnode import Node
import os
import sys
import shutil
import hashlib
from pathlib import Path
import pickle
from queue import Queue
import time
import logging
from FSlogmanger import LogManager
active = "watcher/logs/active.jsonl"
processing = "watcher/logs/processing.jsonl"
logger = logging.getLogger("FS")


class FSManager:
    '''file management'''
    def __init__(self,tagG,mrvec,tagq,tagrq,db_path="save/root.pkl", autosave=True):
        self.default = DEFAULT_PATH
        self.default_name = DEFAULT_NAME
        self.tagG = tagG
        self.root = None
        self.root_store_path = db_path
        self.autosave = autosave
        self.cwd = self.root
        self.selected_nodes = set()
        self.state = 'ideal'
        self.pointer = None
        self.undoStack = Stack()
        self.redoStack = Stack()
        self.hash_queue = []
        self.hash_Master = HashMaster()
        self.mrvec = mrvec
        self.tag_queue = tagq
        self.tag_result_queue = tagrq
        self.rehash_queue = Que(db_path="save/rehash.pkl",autosave=False)
        self.quick_access = pickle_dict(db_path="save/quickA.pkl")
        #  all time are in nano second
        self.average_prifixS_time = None
        self.average_extS_time = None
        self.count_ = 0

        self.log = LogManager(active,processing)

    def process_event(self,event):
        path = self.normalize_path(event['path'])
        print("path",path)
        data = self.get_node_by_path(path)
        node = data['result']
        if node is None:
            print("node is None")
            return
        if node.type == 'd':
            print("node is directory")
            for _ in self._refresh_quick(node):
                pass

    def active(self):
        new_events = self.log.active()
        if new_events:
            print("newevents",new_events)
        for e in new_events:
            self.process_event(e)

        

    def startup(self):
        events = self.log.startup()
        for event in events:
            self.process_event(event)

    # def normalize_path(self,path):
    #     return Path(path).as_posix()
    def normalize_path(self,path):
        driver,path = path.split(':',1)
        path = driver.lower()+':'+path
        return Path(path).as_posix()

    def save(self):
        """
        Save HashMaster state to pickle
        """
        data = {
            "root": self.root
        }
        with open(self.root_store_path, "wb") as f:
            pickle.dump(data, f, protocol=pickle.HIGHEST_PROTOCOL)

    def save_if_autosave(self):
        if self.autosave:
            self.save()

    def load(self):
        """
        Load HashMaster state from pickle
        """
        if not os.path.exists(self.root_store_path):
            logger.error("root.pkl file not exist!")
            
            self.root = Node(self.default_name,self.default,'d')
            self.cwd = self.root
            self.refresh_root()
            # self.refresh_cwd()
            # print(self.cwd.childs)
            
            return

        try:
            with open(self.root_store_path, "rb") as f:
                data = pickle.load(f)

            self.root = data.get("root", Node(self.default_name,self.default,'d'))
            if self.root.name != self.default_name:
                raise Exception("root change")
            self.cwd = self.root
            logger.info(f"{self.root_store_path} is loaded succesfully")

        except Exception:
            # Corrupted pickle → safe reset
            logger.warning(f"{self.root_store_path} Corrupted pickle → safe reset")
            self.root = Node(self.default_name,self.default,'d')
            self.cwd = self.root
            self.refresh_root()

    '''                                                                                
        CORE FEATURE OF FILE MANGEMENT SYSTEM 
        > REFRESH Very Experimental do not touch currently in 99.9% safe stage   
    '''
    def _refresh_quick(self, root_node):
        stack = [root_node]
        print("refresh",root_node.name)
        isChildAdd = False

        while stack:
            node = stack.pop()

            try:
                internal = node.childs
                seen = set()

                for item in os.scandir(node.path):
                    name = item.name
                    seen.add(name)

                    node_ = internal.get(name)

                    # CREATE
                    if node_ is None:

                        type_ = 'd' if item.is_dir(follow_symlinks=False) else 'f'
                        newNode = Node(name, self.normalize_path(item.path), type_)
                        node.add(newNode)

                        st = item.stat(follow_symlinks=False)
                        newNode.size = st.st_size
                        newNode.modified_time = st.st_mtime
                        newNode.created_time = st.st_ctime
                        newNode.mode = st.st_mode

                        self.count_ += 1
                        print(self.count_)


                        # if item.is_symlink():
                        #     newNode.type = 'l'

                        node_ = newNode

                    else:
                        st = item.stat(follow_symlinks=False)

                    # PROCESS
                    if node_.type == 'd' and not item.is_symlink():
                        node_.size = st.st_size
                        node_.modified_time = st.st_mtime
                        
                        # stack.append(node_)
                    else:
                        if not node_.islocked:
                            node_.indicator = 'sync'
                        if needs_rehash(node_, st):
                            self.rehash_queue.put(node_.path)

                    yield

                # DELETE
                for name in tuple(internal):
                    if name not in seen:
                        d_node = internal[name]
                        self._delete_internal(d_node, node)
                    yield

            except Exception as e:
                logger.error(f'{e}')
                yield

    def _refresh(self, root_node):
        stack = [root_node]
        print("refresh",root_node.name)

        while stack:
            node = stack.pop()

            try:
                internal = node.childs
                seen = set()

                for item in os.scandir(node.path):
                    name = item.name
                    seen.add(name)

                    node_ = internal.get(name)

                    # CREATE
                    if node_ is None:

                        type_ = 'd' if item.is_dir(follow_symlinks=False) else 'f'
                        newNode = Node(name, self.normalize_path(item.path), type_)
                        node.add(newNode)

                        st = item.stat(follow_symlinks=False)
                        newNode.size = st.st_size
                        newNode.modified_time = st.st_mtime
                        newNode.created_time = st.st_ctime
                        newNode.mode = st.st_mode

                        self.count_ += 1
                        print(self.count_)


                        # if item.is_symlink():
                        #     newNode.type = 'l'

                        node_ = newNode

                    else:
                        st = item.stat(follow_symlinks=False)

                    # PROCESS
                    if node_.type == 'd' and not item.is_symlink():
                        node_.size = st.st_size
                        node_.modified_time = st.st_mtime
                        stack.append(node_)
                    else:
                        if not node_.islocked:
                            node_.indicator = 'sync'
                        if needs_rehash(node_, st):
                            self.rehash_queue.put(node_.path)

                    yield

                # DELETE
                for name in tuple(internal):
                    if name not in seen:
                        d_node = internal[name]
                        self._delete_internal(d_node, node)
                    yield

            except Exception as e:
                logger.error(f'{e}')
                yield

    def refresh_cwd(self): # work good
        ''' start analysis and updating tree structure from cwd '''
        logger.info(f"refresh start cwd > {self.cwd.path}")
        for _ in self._refresh(self.cwd):
            pass
        logger.info(f"refresh complete cwd > {self.cwd.path}")
        self.save_if_autosave()
    
    def refresh_root(self): # work good
        ''' start analysis and updating tree structure from root '''
        logger.info("full root loading started")
        for _ in self._refresh(self.root):
            pass
        logger.info("full root loading completed")
        self.save_if_autosave()
        self.rehash_queue.save()

    def refresh_node(self,node): # work good
        ''' start analysis and updating tree structure from given node '''
        logger.info(f"refresh start > {node.path}")
        for _ in self._refresh(node):
            pass
        logger.info(f"refresh complete > {node.path}")
        self.save_if_autosave()
    
    """
       > SELECT > UNSELECT > SELECTALL > UNSELECTALL
    """ 
    def select(self,node):  # work good
        if node:
            self.selected_nodes.add(node)
            return True
        return False
    
    def select_name(self,name):
        node = self.get_node(name)
        return self.select(node)

    def unselect(self,node): # work good
        if node in self.selected_nodes:
            self.selected_nodes.remove(node)
            logger.info(f'unselect > {node.name}')
    
    def _select_all(self,node): # work good
        self.select(node)
        if node.type == 'd':
            for name,child in node.childs.items():
                self._select_all(child)
    
    def select_all(self): # work good
        self._select_all(self.cwd)
    
    def unselect_all(self): # work good
        self.selected_nodes.clear()
        logger.info('unselect all')

    """
        > OPEN 
    """
    def _open_file_with_default_app(self,file_path):
        file_path = os.path.abspath(file_path)  # make path absolute
        if not os.path.exists(file_path):
            logger.error(f"open > {file_path} : not found")
            return False

        try:
            if sys.platform == "win32":                    # Windows
                os.startfile(file_path)                    # simplest for Windows

            logger.info(f"open > {file_path} : successfully")

            return True
        except Exception as e:
            logger.info(f" {e}")
            logger.error(f"open > {file_path} :Could not open file > {e}")
            return False
    
    def _set_cwd(self,node):
        self.undoStack.push(self.cwd)
        self.cwd = node
        # self._refresh_basic(node)
        logger.info(f"changed cwd > {node.path}")

    def open(self,node): # work good
        ''' open file with default application '''
        if node.type == 'f':
            self._open_file_with_default_app(node.path)
        else:
            if self.state == 'ideal':
                self.unselect_all()
            self._set_cwd(node)
            logger.info(f"changed cwd >{node.path}")

    """
    > DELETE
    """

    def _delete_internal(self,del_node,parent_node=None): # work good
        ''' delete file/folder from disk and tree structure '''
        if parent_node is None:
            parent_node = self.cwd
        if del_node is None:
            return 
        if del_node.type == 'f':
            self.hash_Master.delete(del_node.path)
            self.mrvec.delete(del_node.path)
            parent_node._del_file_to_search_structure(del_node)

        elif del_node.type == 'd':
            parent_node._del_dir_to_search_structure(del_node)
            for name,child in list(del_node.childs.items()):
                    self._delete_internal(child,del_node)
        del parent_node.childs[del_node.name]
        logger.info(f"delete-internal>{del_node.type} > {del_node.path}")

    def _delete_memory(self,node): # work good
        ''' delete file/folder from memeory only '''
        if node.type == 'f':
            os.remove(node.path)
            logger.info(f"delete-memory > file > {node.path}")
        elif node.type == 'd':
            shutil.rmtree(node.path)
            logger.info(f"delete-memory > dir > {node.path}")
    
    def delete_node(self,node): # work good
        ''' delete file/folder from disk and tree structure '''
        self._delete_memory(node)
        # self.cwd.increment(node.size*-1)
        self._delete_internal(node)
        self.save_if_autosave()
    
    def delete(self,filename):
        node = self.get_node(filename)
        if node:
            self.delete_node(node)
            return True
        return False

    # def trash(self,filepath):

    """
    > CUT > COPY > PASTE
    """
    def _set_pointer(self,node): # work good
        self.pointer = node

    def _get_pointer(self): # work good
        return self.pointer
    
    def cut(self): # work good
        if self.state == 'ideal':
            if self.selected_nodes:
                self.state = 'move'
                self._set_pointer(self.cwd)
                logger.info("move mode activated")

    def copy(self): # work good
        if self.state == 'ideal':
            if self.selected_nodes:
                self.state = 'copy'
                self._set_pointer(self.cwd)
                logger.info("copy mode activated")
    
    def _paste_for_move_helper(self,node):
        try:
            shutil.move(node.path,self.cwd.path)
            logger.info(f"moved {node.path} to {self.cwd.path}")
            p_node = self._get_pointer()
            # p_node.increment(node.size*-1)
            self._delete_internal(node,p_node)
            return True
        except Exception:
            return False

    def _paste_for_move(self): # work good
            if self.selected_nodes:
                result = [(node.name,self._paste_for_move_helper(node)) for node in self.selected_nodes]    
                logger.info("paste completed, back to ideal mode")
                return result
            return []

    def _paste_for_copy_helper(self,node):
        try:
            if node.type == 'f':
                shutil.copy2(node.path,self.cwd.path)
                logger.info(f"copied {node.path} to {self.cwd.path}")
            elif node.type == 'd':
                dest_path = os.path.join(self.cwd.path,node.name)
                shutil.copytree(node.path,dest_path)
                logger.info(f"copied directory {node.path} to {dest_path}")
            return True
        except Exception:
            return False

    def _paste_for_copy(self): # work good
        if self.selected_nodes:
            result = [(node.name,self._paste_for_copy_helper(node)) for node in self.selected_nodes]
            logger.info("paste completed, back to ideal mode")
            return result
        return []

    def paste(self): # work good
        '''there is a issue of already exist thing'''#<<<<<<<<<<ERROR
        if self.state == 'move':
            result = self._paste_for_move()
            self.unselect_all()
            # self.refresh_cwd()
            self.state = 'ideal'
            return result
        elif self.state == 'copy':
            result = self._paste_for_copy()
            self.unselect_all()
            # self.refresh_cwd()
            self.state = 'ideal'
            return result
        return []
    
    """
    > CREATE
    """
    def _write_content_to_file(self,filepath,content):
        with open(filepath,"w") as f:
            f.write(f'{content}\n')

    def _append_content_to_file(self,filepath,content):
        with open(filepath,"a") as f:
            f.write(f'{content}\n')

        
    def _create_dir_memory(self,dir_name,p_node= None): # work good
        if p_node is None:
            p_node = self.cwd
            new_dir_path = os.path.join(p_node.path,dir_name)
        if not os.path.exists(new_dir_path):
            os.makedirs(new_dir_path)
            logger.info("directory created at:",new_dir_path) 
            return True
        else:
            return False
    
    def _create_dir_internal(self,dir_name,p_node= None): # work good
        if p_node is None:
            p_node = self.cwd
        newNode = Node(dir_name,self.normalize_path(os.path.join(p_node.path,dir_name)),'d')
        p_node.add(newNode)
        logger.info("directory node created at:",newNode.path)
        return newNode
    
    def _create_file_memory(self,file_name,content="",p_node= None): # work good
        if p_node is None:
            p_node = self.cwd
        new_file_path = os.path.join(p_node.path,file_name)
        if not os.path.exists(new_file_path):
            self._write_content_to_file(new_file_path,content)
            logger.info("file created at:",new_file_path)
            return True
        return False
    
    def _create_file_internal(self,file_name,p_node= None): # work good
        if p_node is None:
            p_node = self.cwd
        newNode = Node(file_name,self.normalize_path(os.path.join(p_node.path,file_name)),'f')
        p_node.add(newNode)
        logger.info("file node created at:",newNode.path)
        return newNode

    def create_dir(self,dir_name,p_node= None):
        isDone = self._create_dir_memory(dir_name,p_node)
        if isDone:
            node = self._create_dir_internal(dir_name,p_node)
            node._config_stat()
            self.save_if_autosave()
            logger.info(f"create in dir > {dir_name}")
            return node.to_dict()
        else:
            return self.create_dir(filename_dup_normalizer(dir_name),p_node)

    def create_file(self,file_name,content="",p_node= None):
        isDone = self._create_file_memory(file_name,content,p_node)
        if isDone:
            node = self._create_file_internal(file_name,p_node)
            self.hash_queue.append(node)
            node._config_stat()
            self.save_if_autosave()
            logger.info(f"create in file > {file_name}")
            return node.to_dict()
        else:
            return self.create_file(filename_dup_normalizer(file_name),content,p_node)
    
    def write_to_file(self,node,content):
        if node.type == 'f':
            self._write_content_to_file(node.path,content)
            node._config_stat()
            self.save_if_autosave()
            logger.info(f"written to file > {node.path}")
        else:
            logger.error(f"cannot write to a directory > {node.path}")
    
    def append_to_file(self,node,content):
        if node.type == 'f':
            self._append_content_to_file(node.path,content)
            node._config_stat()
            self.save_if_autosave()
            logger.info(f"append to file > {node.path}")
        else:
            logger.error(f"cannot append to a directory > {node.path}")

    """
    > SHOW LIST

    """

    def show_list(self,filter = None) -> list: # work good
        ''' show list of files and folders in current working directory '''
        logger.info(f"call show list>: {self.cwd.path}")
        result = []
        for name,child in self.cwd.childs.items():
            result.append(child)
        return result
    """
    > HOME >GOTO > UNDO 

    """

    def go_to_root(self): # work good
        self._set_cwd(self.root)   
    
    def go_to(self,name): # work good
        node = self.get_node(name)
        if node:
            self.open(node)
            return True
        else:
            logger.info(f"{name} not found in cwd")
            return False
    
    def go_back(self): # work good
        if self.state == 'ideal':
            self.unselect_all()
        if self.undoStack.empty():
            logger.info("no undo -> Empty")
            print("no undo -> Empty")
            return False
        # it not need history push
        self.redoStack.push(self.cwd)
        prev_node = self.undoStack.pop()
        self.cwd = prev_node
        return True

    def go_forward(self): # work good
        if self.state == 'ideal':
            self.unselect_all()
        if self.redoStack.empty():
            logger.info("no redo->empty")
            print("no redo->empty")
            return
        # it not need history push
        prev_node = self.redoStack.pop()
        self.open(prev_node)

    def go_to_address(self,path):
        data = self.get_node_by_path(path)
        r = data['result']
        m = data['message']
        if r:
            self.open(r)
            return (True,m)
        return (False,m)

    """
   > RENAME

    """
    def _rename_internal(self,filename,node,p_node=None):
        if p_node is None:
            p_node = self.cwd
        if node.type == 'd':
            p_node._del_dir_to_search_structure(node)    
        else:
            self.hash_Master.delete(node.path)
            self.mrvec.delete(node.path)
            p_node._del_file_to_search_structure(node)    

        node.path  = node.path[:-len(node.name)]+filename #path change
        

        del p_node.childs[node.name]
        p_node.childs[filename] = node
        node.parent = p_node
        
        node.name = filename
        node._config_stat()
        if node.type == 'd':
            p_node._add_dir_to_search_structure(node)    
        else:
            p_node._add_file_to_search_structure(node)
            self.hash_queue.append(node)    
          
    def _rename_memory(self,name,node):
        old_add = node.path
        new_add = node.path[:-len(node.name)]+name
        try:
            os.rename(old_add,new_add)
            return True
        except Exception as e:
            return False

    def rename_node(self,name,node,p_node=None):
        isDone = self._rename_memory(name,node)
        if isDone:
            self._rename_internal(name,node,p_node)
            logger.info(f"rename > '{node.name}' to '{name}'")
            return {
            "status":True,
            "msg": "name rename done"
            }
        return {
            "status":False,
            "msg": "invalid charcters used"
        }
        
    def rename(self,old,new):
        if any([new.__contains__(char)for char in '/*?"<>:|']):
            return {
            "status":False,
            "msg": 'not use this any this character / * ? " < > : |'
        }
        if new not in self.cwd.childs:
            node = self.get_node(old)
            if node:
                return self.rename_node(new,node)

        return {
            "status":False,
            "msg": "name alredy exist"
        }
        

    """
     > SEARCH
    """ 
    "PRIFIX AND EXTENSION"
    def search_helper_prifix(self,node,prifix,results,type_,subdir = True):
        if not prifix:
            if type_ == 'd':
                result = node.prifixSearch_folder.get_all()
            else:
                result = node.prifixSearch_file.get_all()
        elif type_ == 'd':
            result = node.search_prifix_folder(prifix)
        else:
            result = node.search_prifix_file(prifix)

        results += result
        if subdir:
            for item in node.childs.values():
                if item.type == 'd':
                    self.search_helper_prifix(item,prifix,results,type_)
        return results

    def search_helper_ext(self,node,ext,results,subdir = True):
        result = node.search_ext(ext)
        results += result
        if subdir:
            for item in node.childs.values():
                if item.type == 'd':
                    self.search_helper_ext(item,ext,results)
        return results

    def search_prifix(self,prifix,type_,subdir = True):
        results = []
        ns1 =time.perf_counter_ns()
        self.search_helper_prifix(self.cwd,prifix,results,type_,subdir)
        ns2 =time.perf_counter_ns()
        self.average_prifixS_time = ns2-ns1
        return results

    def search_prifix_all(self,prifix,type_):
        results = []
        self.search_helper_prifix(self.root,prifix,results,type_,True)
        return results
    
    def search_ext(self,ext,subdir = True):
        results = []
        ns1 =time.perf_counter_ns()
        self.search_helper_ext(self.cwd,ext,results,subdir)
        ns2 =time.perf_counter_ns()
        self.average_extS_time = ns2-ns1
        return results

    def search_ext_all(self,ext):
        results = []
        self.search_helper_ext(self.root,ext,results,True )
        return results
    
    def filter_prifix(self,prifix,files):
        results = []
        for file in files:
            if file['name'].startswith(prifix):
                results.append(file)
        return results

    def filter_substring(self,substring,files):
        results = []
        for file in files:
            if substring in  file['name']:
                results.append(file)
        return results


    def ultra_search(self,search_for,search_where,prifix,extension,substring):
        results =[]
        Both = True if search_for == 'fd' else False
       
        if extension:
            print("enter extension")
            if search_where == 'pd':
                results = self.search_ext(extension,False)
            elif search_where == 'sd':
                results = self.search_ext(extension,True)
            elif search_where == 'rd':
                results = self.search_ext_all(extension)

            if prifix:
                results = self.filter_prifix(prifix,results)

            if substring:
                results = self.filter_substring(substring,results)
            return results
        
      
        if search_for == 'f' or Both:
            if search_where == 'pd':
                results += self.search_prifix(prifix,'f',False)
            elif search_where == 'sd':
                results += self.search_prifix(prifix,'f',True)
            elif search_where == 'rd':
                results += self.search_prifix_all(prifix,'f')
        if search_for == 'd' or Both:
            if search_where == 'pd':
                results += self.search_prifix(prifix,'d',False)
            elif search_where == 'sd':
                results += self.search_prifix(prifix,'d',True)
            elif search_where == 'rd':
                results += self.search_prifix_all(prifix,'d')
        if substring:
            results = self.filter_substring(substring,results)

        return results



    "HASH"
    def search_hash_by_path(self, path: str):
        return self.hash_Master.search_hash_by_path(path)
        
    def search_paths_by_hash(self, file_hash: str):
        return self.hash_Master.search_paths_by_hash(file_hash)

    def search_duplicate_files(self):
        return self.hash_Master.search_duplicate_files()
       
    def lock_file(self,node):
        if node.type == 'f':
            node.lock_hash = node.hash
            node.islocked = True
            return True
        return False

    def unlock_file(self,node):
        node.lock_hash = None
        node.islocked = False
    
    def is_corupted(self,node):
        if not os.path.exists(node.path):
            return {"status": "NOT_FOUND"}

        stat = os.stat(node.path)

        # Silent corruption case
        if (
            stat.st_size == node.size
            and stat.st_mtime == node.modified_time
            and node.hash != file_hash(node.path)
        ):
            return {
                "status": "SILENT_CORRUPTION",
            }

        return {"status": "OK"}


    """
        EXTRA HELPING FEATURES 
        >GET NODE > GET NODE BY PATH
    """

    def get_node(self,filename): # work good
        return self.cwd.get(filename)

    def path_verifier(self,path):
        return True if self.root.path in path else False

    def path_breaker(self,path):
        rootv=self.root.path.split('/')
        pathv=path.split('/')
        length = len(rootv)
        return pathv[length:]
    
    def _path_break_to_dict(self,path):
        if self.path_verifier(path):
            rootv=self.root.path.split('/')
            pathv=path.split('/')
            length = len(rootv)
            data = {"HOME":self.root.path}
            for name in pathv[length:]:
                if name:
                    data[name] = f'{self.root.path}/{name}'
            return data
        return {}

    def path_break_cwd(self):
        return self._path_break_to_dict(self.cwd.path)
        
    def get_node_by_path(self,path):
        if self.path_verifier(path):
            results = self.path_breaker(path)
            root = self.root
            for pathname in results:
                if pathname in root.childs:
                    root = root.childs[pathname]
                elif pathname:
                    return {
                        'result':None,
                        'message':'path not exist'
                    }
              
            return {
                    'result':root,
                    'message':'path exist'
            }
        return {
                    'result':None,
                    'message':'path is incorrect or formate is incorrect'
            }


    """
        performance table
    """
    def _status(self):
        return f'''
        FS State: Active
        Indexed File: {len(self.mrvec.path_to_vector)}
        pending tag jobs: {self.tag_queue.__len__()}
        pending vector jobs: {self.tag_queue.__len__()}
        '''
   
    def _stats(self):
        return f'''
        Indexed File: {len(self.mrvec.path_to_vector)}
       Average Search Time:
                prifix -> {self.average_prifixS_time}
                extension -> {self.average_extS_time}
                context -> {self.mrvec.average_contextS_time}
        '''

        
    """
    > CONTEXT CHANGE DETECT 
    
    """
    def changes_detector(self,node):

        hash_ = file_hash(node.path)
        if node.hash != hash_ and hash_:
            if node.hash:
                if node.islocked:
                    node.indicator = 'lock_m'
                else:
                    node.indicator = 'modified'
                print("context change detected",node.name)
            logger.info(f'file content changes detected > {node.path}')
            ("hash updt")
            node.hash = hash_ # update hash
            self.hash_Master.insert(node.path,hash_) # update and add hash in path_to_hash dictss
            result = name_ext(node.name)
            if result['ext'] in ALLOWED_TAGS_EXT:
                node.state = "pending"
                path_ = node.path
                self.tag_queue.put(path_)
                logger.info(f"{node.name} > tag queue")
            # genrate tags and assign  to them
            
        node._config_stat()

    
    """
    > BACKGROUND TASK AND TAG GENRATION
    
    """
    

    def background_index_step1(self):
        logger.info("background task start")
        if self.tag_result_queue.empty():
            return False
        
    
        tag_data = self.tag_result_queue.get()
        data = self.get_node_by_path(tag_data['path'])
        node_ = data['result']
        mgs = data['message']
        logger.info(mgs)
        if node_:
            tags = tag_data['tags']
            if tags:
                print(tags)
                vector = self.mrvec.convert_tags_to_vector(tags)

                node_.vector = vector
                node_.tags = tags
                # print(node_.tags)

                self.mrvec.insert(node_.path, vector)
                # print(self.mrvec.path_to_vector)
            node_.state = "indexed"

            logger.info(f"{node_.path} > indexed")
        return True

    def background_index_step2(self):
        logger.info("background task start")
        if self.rehash_queue.empty():
            return False
    
        path_ = self.rehash_queue.get()
        data = self.get_node_by_path(path_)
        node_ = data['result']
        mgs = data['message']
        logger.info(mgs)
        if node_:
            self.changes_detector(node_)
        return True



if __name__ == '__main__':
    fs = FSManager([],[])
    fs.load()
    data = fs.ultra_search('d','pd','','','')
    print(data)
