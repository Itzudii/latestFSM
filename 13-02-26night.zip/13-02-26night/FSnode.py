# import os
# from FS.prifixSearch import Trie
# from FS.extSearch import CustomHashMap
# from FS.useful import filemode_readable,file_type,formate_sttime,name_ext
# import logging
# logger = logging.getLogger("FS")


# class Node:
#     def __init__(self,name,path,type_):
#         self.path = path
#         self.name = name
#         self.type = type_

#         self.parent = None
#         self.childs = {} if self.type == 'd' else None

#         self.prifixSearch_file = Trie() if self.type == 'd' else None
#         self.prifixSearch_folder = Trie() if self.type == 'd' else None
#         self.extensionSearch =  CustomHashMap() if self.type == 'd' else None

#         self.state = "indexed"
#         self.indicator = "sync"
#         self.islocked = False
#         self.locked_hash = None


#         self.details = name_ext(name)

#         self.hash = None
#         self.vector = None
#         self.tags = None

#         self.size = 0
#         self.modified_time = None
#         self.created_time = None
#         self.mode = None

#     def increment(self,diff):
#         print("increment",self.name,self.parent.name if self.parent else None)
#         self.size += diff
#         if self.parent:
#             self.parent.increment(diff)

#     def _config_stat(self):
#         st = os.stat(self.path)
#         self.size = st.st_size
#         # if self.type =='f':
#         #     old_size = self.size
#         #     new_size = st.st_size
#         #     diff = new_size - old_size
            
#             # if diff != 0:
#                 # self.increment(diff)
#         self.modified_time = st.st_mtime
#         self.created_time = st.st_ctime
#         self.mode = st.st_mode      
    
#     def config_by_path(self,path):
#         st = os.stat(path)
#         self._config_stat(st)

#     def add(self, node):
#         if self.childs is None:
#             raise TypeError("Cannot add child to non-directory")

#         self.childs[node.name] = node
#         node.parent = self

#         if node.type == 'd':
#             if self.prifixSearch_folder:
#                 self.prifixSearch_folder.insert(node.name, node.path)

#         if node.type == 'f':
#             if self.prifixSearch_file:
#                 self.prifixSearch_file.insert(node.name, node.path)
#             if self.extensionSearch:
#                 self.extensionSearch.insert(node.name, node.path)

#     def _add_file_to_search_structure(self,node):
#         self.prifixSearch_file.insert(node.name,node.path)
#         self.extensionSearch.insert(node.name,node.path)

#     def _add_dir_to_search_structure(self,node):
#         self.prifixSearch_folder.insert(node.name,node.path)
#     # def remove(self, name):
#     #     if self.childs is None:
#     #         return None

#     #     node = self.childs.pop(name, None)
#     #     if not node:
#     #         return None

#     #     if self.prifixSearch:
#     #         self.prifixSearch.delete(node.name, node.path)

#     #     if node.type == 'f' and self.extensionSearch:
#     #         self.extensionSearch.delete(node.name, node.path)

#     #     return node

#     def get(self,name,alter = None):
#         if name in self.childs:
#             return self.childs[name]
#         return alter

    
#     def _del_file_to_search_structure(self,node):
#         if self.prifixSearch_file is None :
#             return False
#         self.prifixSearch_file.delete(node.name,node.path)
#         self.extensionSearch.delete(node.name,node.path)
#         return True

#     def _del_dir_to_search_structure(self,node):
#         if self.prifixSearch_folder is None :
#             return False
#         self.prifixSearch_folder.delete(node.name,node.path)
#         return True


#     def search_prifix_file(self,prifix):
#         return self.prifixSearch_file.search_by_prefix(prifix)
    
#     def search_prifix_folder(self,prifix):
#         return self.prifixSearch_folder.search_by_prefix(prifix)

#     def search_ext(self,ext):
#         return self.extensionSearch.get_by_extension(ext)

    
#     def to_dict(self):
#         return {
#             'name': self.name,
#             'path': self.path,
#             'indicator': self.indicator,
#             'type': self.type,
#             'size': self.size,
#             'modified_time': self.modified_time,
#             'created_time': self.created_time,
#             'mode': self.mode,
#         } 
    
#     def __repr__(self):
#         return f"Node(name={self.name}, path={self.path}, type={self.type})"

import os
from FS.prifixSearch import Trie
from FS.extSearch import CustomHashMap
from FS.useful import name_ext


class Node:
    __slots__ = (
        "path", "name", "type",
        "parent", "childs",
        "prifixSearch_file", "prifixSearch_folder", "extensionSearch",
        "state", "indicator", "islocked", "locked_hash",
        "details", "hash", "vector", "tags",
        "size", "modified_time", "created_time", "mode"
    )

    def __init__(self, name, path, type_):
        self.path = path
        self.name = name
        self.type = type_

        self.parent = None
        self.childs = {} if type_ == 'd' else None

        # Lazy structures (huge speed improvement)
        self.prifixSearch_file = None
        self.prifixSearch_folder = None
        self.extensionSearch = None

        self.state = "indexed"
        self.indicator = "sync"
        self.islocked = False
        self.locked_hash = None

        self.details = name_ext(name)

        self.hash = None
        self.vector = None
        self.tags = None

        self.size = 0
        self.modified_time = None
        self.created_time = None
        self.mode = None

    # ⚡ iterative increment (faster than recursion)
    def increment(self, diff):
        node = self
        while node:
            node.size += diff
            node = node.parent

    def _config_stat(self):
        st = os.stat(self.path)
        self.size = st.st_size
        self.modified_time = st.st_mtime
        self.created_time = st.st_ctime
        self.mode = st.st_mode

    def config_by_path(self, path):
        self.path = path
        self._config_stat()

    def add(self, node):
        if self.childs is None:
            raise TypeError("Cannot add child to non-directory")

        self.childs[node.name] = node
        node.parent = self

        # Lazy initialize search structures
        if node.type == 'd':
            if self.prifixSearch_folder is None:
                self.prifixSearch_folder = Trie()
            self.prifixSearch_folder.insert(node.name, node.path)

        elif node.type == 'f':
            if self.prifixSearch_file is None:
                self.prifixSearch_file = Trie()
            if self.extensionSearch is None:
                self.extensionSearch = CustomHashMap()

            self.prifixSearch_file.insert(node.name, node.path)
            self.extensionSearch.insert(node.name, node.path)

    def get(self, name, alter=None):
        if self.childs is None:
            return alter
        return self.childs.get(name, alter)

    def _add_dir_to_search_structure(self,node):
        if self.prifixSearch_folder is None:
            self.prifixSearch_folder = Trie()
        self.prifixSearch_folder.insert(node.name, node.path)

    def _add_file_to_search_structure(self,node):
        if self.prifixSearch_file is None:
            self.prifixSearch_file = Trie()
        if self.extensionSearch is None:
            self.extensionSearch = CustomHashMap()
        self.prifixSearch_file.insert(node.name, node.path)
        self.extensionSearch.insert(node.name, node.path)


    def _del_file_to_search_structure(self, node):
        if self.prifixSearch_file:
            self.prifixSearch_file.delete(node.name, node.path)
        if self.extensionSearch:
            self.extensionSearch.delete(node.name, node.path)
        return True

    def _del_dir_to_search_structure(self, node):
        if self.prifixSearch_folder:
            self.prifixSearch_folder.delete(node.name, node.path)
        return True

    def search_prifix_file(self, prifix):
        if self.prifixSearch_file:
            return self.prifixSearch_file.search_by_prefix(prifix)
        return []

    def search_prifix_folder(self, prifix):
        if self.prifixSearch_folder:
            return self.prifixSearch_folder.search_by_prefix(prifix)
        return []

    def search_ext(self, ext):
        if self.extensionSearch:
            return self.extensionSearch.get_by_extension(ext)
        return []

    def to_dict(self):
        return {
            'name': self.name,
            'path': self.path,
            'indicator': self.indicator,
            'type': self.type,
            'size': self.size,
            'modified_time': self.modified_time,
            'created_time': self.created_time,
            'mode': self.mode,
        }

    def __repr__(self):
        return f"Node(name={self.name}, path={self.path}, type={self.type})"
