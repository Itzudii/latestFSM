import webview
import threading
import time
from queue import Queue
import os


from FSTags import TagGenerator
from FSmain import FSManager
from FSCLI import CLI

from FSvector import MrVectorExpert
from FSlog_config import setup_logger

from FSgui import FSProjectGUI

class Controller:
    def __init__(self) -> None:
        self.vec = MrVectorExpert()
        # self.vec.load_model()
        self.vec.load()
   
        self.tag = TagGenerator()

        self.fs = FSManager(self.tag,self.vec)
        self.fs.load()

        self.cli = CLI(self.fs)

        self.t2 = threading.Thread(target=self.cli.background_worker, daemon=True)

        self.t2.start()

