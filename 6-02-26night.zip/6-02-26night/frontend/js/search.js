function switchTab(tab) {
    const tabs = document.querySelectorAll('.tab');
    tabs.forEach(t => t.classList.remove('active'));
    event.target.classList.add('active');

    // You can add different functionality for different tabs here
    if (tab === 'text') {
        document.getElementById('searchText').placeholder = 'Enter text to search within files...';
    } else {
        document.getElementById('searchText').placeholder = 'Enter search term...';
    }
}

function performSearch() {
    const searchText = document.getElementById('searchText').value;
    const fileExtension = document.getElementById('fileExtension').value;
    const substringSearch = document.getElementById('substringSearch').value;
    const searchFor = document.getElementById('searchFor').value;
    const searchWhere = document.getElementById('searchWhere').value;
    const output = document.getElementById('output').value;
    const pythonOutput = document.getElementById('pythonOutput').checked;

    const resultsList = document.getElementById('resultsList');

    if (!searchText && !fileExtension && !substringSearch) {
        resultsList.innerHTML = '<div class="no-results">Please enter a search term, file extension, or substring.</div>';
        return;
    }

    // Simulated search results for demonstration
    const mockResults = [
        'D:\\Path-Finder\\main\\src\\components\\search.js',
        'D:\\Path-Finder\\main\\src\\utils\\file-search.js',
        'D:\\Path-Finder\\main\\tests\\search-test.js',
        'D:\\Path-Finder\\docs\\search-guide.md',
        'D:\\Path-Finder\\config\\search-config.json',
        'D:\\Path-Finder\\lib\\search-engine.dll',
        'D:\\Path-Finder\\assets\\images\\search-icon.png',
        'D:\\Path-Finder\\modules\\advanced-search.py'
    ];

    // Filter mock results based on search criteria
    let filteredResults = mockResults.filter(path => {
        // Check search text in full path
        if (searchText && !path.toLowerCase().includes(searchText.toLowerCase())) {
            return false;
        }
        // Check file extension
        if (fileExtension && !path.endsWith(fileExtension)) {
            return false;
        }
        // Check substring in filename only
        if (substringSearch) {
            const filename = path.split('\\').pop();
            if (!filename.toLowerCase().includes(substringSearch.toLowerCase())) {
                return false;
            }
        }
        return true;
    });

    if (filteredResults.length === 0) {
        resultsList.innerHTML = '<div class="no-results">No files found matching your criteria.</div>';
        return;
    }

    // Format results based on output type
    if (output === 'filename') {
        filteredResults = filteredResults.map(path => path.split('\\').pop());
    } else if (output === 'relative') {
        filteredResults = filteredResults.map(path => path.replace('D:\\Path-Finder\\', ''));
    }

    // Format for Python if selected
    if (pythonOutput) {
        const pythonList = '[\n    r"' + filteredResults.join('",\n    r"') + '"\n]';
        resultsList.innerHTML = `<pre>${pythonList}</pre>`;
    } else {
        resultsList.innerHTML = filteredResults.map((path, index) => {
            const filename = path.split('\\').pop();
            const fullPath = path;
            const fileExt = filename.substring(filename.lastIndexOf('.'));

            // Determine icon based on file extension
            let icon = '📄';
            if (['.js', '.jsx', '.ts', '.tsx'].includes(fileExt)) icon = '📜';
            else if (['.json', '.xml', '.yaml', '.yml'].includes(fileExt)) icon = '📋';
            else if (['.md', '.txt', '.doc', '.docx'].includes(fileExt)) icon = '📝';
            else if (['.png', '.jpg', '.jpeg', '.gif', '.svg'].includes(fileExt)) icon = '🖼️';
            else if (['.py', '.java', '.cpp', '.c'].includes(fileExt)) icon = '💻';
            else if (['.html', '.css'].includes(fileExt)) icon = '🌐';
            else if (['.zip', '.rar', '.7z', '.tar'].includes(fileExt)) icon = '📦';
            else if (['.dll', '.exe', '.app'].includes(fileExt)) icon = '⚙️';

            return `
                        <div class="result-item" onclick="copyToClipboard('${fullPath.replace(/'/g, "\\'")}', this)">
                            <div class="result-icon">${icon}</div>
                            <div class="result-content">
                                <div class="result-filename">${filename}</div>
                                <div class="result-path">${fullPath}</div>
                            </div>
                            <div class="result-status">✓ Copied</div>
                        </div>
                    `;
        }).join('');
    }
}

function copyToClipboard(text, element) {
    navigator.clipboard.writeText(text).then(() => {
        // Add copied class for visual feedback
        element.classList.add('copied');

        // Remove all other copied classes
        document.querySelectorAll('.result-item.copied').forEach(item => {
            if (item !== element) {
                item.classList.remove('copied');
            }
        });

        // Remove copied class after 2 seconds
        setTimeout(() => {
            element.classList.remove('copied');
        }, 2000);

        console.log('Copied to clipboard:', text);
    }).catch(err => {
        console.error('Failed to copy:', err);
        alert('Failed to copy to clipboard');
    });
}



// Allow Enter key to trigger search
document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('searchText').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    document.getElementById('fileExtension').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    document.getElementById('substringSearch').addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
});
// window.addEventListener("pywebviewready", refresh)
