import time
import os
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler


class SimpleFSHandler(FileSystemEventHandler):
    """
    This class receives EVENTS from the OS.
    Think of these as your 'refresh endpoints'.
    """

    def on_created(self, event):
        self._handle(event, "CREATED")

    def on_modified(self, event):
        self._handle(event, "MODIFIED")

    def on_deleted(self, event):
        self._handle(event, "DELETED")

    def on_moved(self, event):
        print(f"MOVED  : {event.src_path} -> {event.dest_path}")

    def _handle(self, event, action):
        path = event.src_path

        # skip directory metadata noise if you want
        is_dir = event.is_directory

        # detect symlink safely
        is_link = os.path.islink(path)

        print(
            f"{action:9} | "
            f"{'DIR' if is_dir else 'FILE'} | "
            f"{'SYMLINK' if is_link else 'NORMAL'} | "
            f"{path}"
        )


def watch(path):
    observer = Observer()
    handler = SimpleFSHandler()

    observer.schedule(
        handler,
        path=path,
        recursive=True  # set False if you want only cwd
    )

    observer.start()
    print(f"👀 Watching: {path}")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()

    observer.join()


if __name__ == "__main__":
    watch(os.getcwd())
