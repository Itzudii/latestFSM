class UltraSearch:
    def __init__(self):
        self.subString = {}
        self.prifix = {}
        self.ext = {}